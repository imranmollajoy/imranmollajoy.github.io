import"../../../../chunks/posts-efd8586d.js";import{l}from"../../../../chunks/_page-b527489b.js";export{l as load};
