import"../../chunks/posts-efd8586d.js";import{l}from"../../chunks/_page-c208e13c.js";export{l as load};
