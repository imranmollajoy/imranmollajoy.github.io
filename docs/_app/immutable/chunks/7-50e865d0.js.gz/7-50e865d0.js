import{default as t}from"../components/pages/posts/passkeys-now-available-in-chrome/_page.svx-0676d0c5.js";export{t as component};
