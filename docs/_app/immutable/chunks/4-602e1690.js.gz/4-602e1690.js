import{_ as r}from"./_page-b527489b.js";import{default as t}from"../components/pages/posts/category/_page.svelte-5c0eb79a.js";export{t as component,r as universal};
