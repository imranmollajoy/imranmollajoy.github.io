import{default as t}from"../components/pages/_page.svelte-7711a3a2.js";const e=!0;export{t as component,e as server};
