import{default as t}from"../components/pages/_page.svelte-8597d7d3.js";const e=!0;export{t as component,e as server};
