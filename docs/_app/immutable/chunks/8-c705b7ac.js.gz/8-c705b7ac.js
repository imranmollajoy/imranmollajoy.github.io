import{default as t}from"../components/pages/posts/passkeys-now-available-in-chrome/_page.svx-c91fa77f.js";export{t as component};
