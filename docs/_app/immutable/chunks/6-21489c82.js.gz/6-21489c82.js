import{default as t}from"../components/pages/posts/create-horizontal-scroll-section-html-css-js/_page.svx-af095251.js";export{t as component};
