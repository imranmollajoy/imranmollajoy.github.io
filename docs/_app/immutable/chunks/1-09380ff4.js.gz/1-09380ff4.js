import{default as t}from"../components/error.svelte-17fb23d3.js";export{t as component};
