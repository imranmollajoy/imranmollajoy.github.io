import{default as t}from"../components/pages/posts/ad-free-alternatives-on-android-and-ios/_page.svx-4c31c601.js";export{t as component};
