import{_ as r}from"./_page-c208e13c.js";import{default as t}from"../components/pages/_page.svelte-7711a3a2.js";export{t as component,r as universal};
