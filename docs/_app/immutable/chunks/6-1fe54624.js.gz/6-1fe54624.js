import{default as t}from"../components/pages/posts/create-button-component-for-svelte/_page.svx-86464069.js";export{t as component};
