import{default as t}from"../components/error.svelte-d41c6714.js";export{t as component};
