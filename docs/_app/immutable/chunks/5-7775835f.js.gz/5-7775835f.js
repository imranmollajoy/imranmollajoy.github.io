import{default as t}from"../components/pages/posts/create-button-component-for-svelte/_page.svx-70a308b3.js";export{t as component};
