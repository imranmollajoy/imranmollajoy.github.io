import{_ as r}from"./_layout-af132c39.js";import{default as t}from"../components/pages/_layout.svelte-bdb04e6c.js";export{t as component,r as universal};
