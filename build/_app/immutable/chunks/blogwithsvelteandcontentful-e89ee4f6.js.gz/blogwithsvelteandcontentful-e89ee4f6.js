const t=""+new URL("../assets/blogwithsvelteandcontentful-359e038f.png",import.meta.url).href;export{t as default};
