const t=""+new URL("../assets/tkn-e380795b.png",import.meta.url).href;export{t as default};
