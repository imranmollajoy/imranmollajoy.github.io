const t=""+new URL("../assets/dtg-b-cdb586f9.png",import.meta.url).href;export{t as default};
