import{default as t}from"../components/error.svelte-901dc108.js";export{t as component};
