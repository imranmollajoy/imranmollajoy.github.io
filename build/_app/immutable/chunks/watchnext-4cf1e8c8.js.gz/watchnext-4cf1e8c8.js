const t=""+new URL("../assets/watchnext-33204039.png",import.meta.url).href;export{t as default};
