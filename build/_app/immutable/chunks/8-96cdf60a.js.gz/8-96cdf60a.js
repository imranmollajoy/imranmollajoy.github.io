import{default as t}from"../components/pages/portfolios/watchnext/_page.svx-1d092821.js";export{t as component};
