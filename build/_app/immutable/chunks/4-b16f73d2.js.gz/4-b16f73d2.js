import{default as t}from"../components/pages/portfolios/blog-with-svelte/_page.svx-1c4178c2.js";export{t as component};
