import{default as t}from"../components/pages/portfolios/dummy-text-generator/_page.svx-4d619507.js";export{t as component};
