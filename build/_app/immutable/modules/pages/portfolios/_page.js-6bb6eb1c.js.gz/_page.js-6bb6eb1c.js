import{l}from"../../../chunks/_page-dc5b7bcd.js";export{l as load};
