import{l}from"../../chunks/_page-a1b7d4c2.js";export{l as load};
