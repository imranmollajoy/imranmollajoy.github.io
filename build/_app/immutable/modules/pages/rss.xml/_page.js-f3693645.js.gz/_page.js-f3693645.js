import{l}from"../../../chunks/_page-02a16c4f.js";export{l as load};
