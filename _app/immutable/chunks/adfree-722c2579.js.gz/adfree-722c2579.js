const e=""+new URL("../assets/adfree-ef09773e.png",import.meta.url).href;export{e as default};
