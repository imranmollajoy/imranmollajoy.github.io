import{default as t}from"../components/pages/posts/differences-between-ssg-and-spa/_page.svx-8a91465c.js";export{t as component};
