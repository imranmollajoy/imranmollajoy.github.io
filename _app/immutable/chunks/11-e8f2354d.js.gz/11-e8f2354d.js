import{default as t}from"../components/pages/posts/differences-between-ssg-and-spa/_page.svx-1979a428.js";export{t as component};
