import{default as t}from"../components/pages/posts/ad-free-alternatives-on-android-and-ios/_page.svx-204d2e33.js";export{t as component};
