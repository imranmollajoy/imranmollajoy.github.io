import{default as t}from"../components/pages/posts/why-i-chose-sveltekit-over-gatsby/_page.svx-7e2a1966.js";export{t as component};
