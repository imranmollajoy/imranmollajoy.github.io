import{default as t}from"../components/pages/portfolios/dummy-text-generator/_page.svx-cb47fb9c.js";export{t as component};
