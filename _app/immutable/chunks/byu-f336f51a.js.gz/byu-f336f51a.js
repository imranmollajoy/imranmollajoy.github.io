const a=""+new URL("../assets/byu-a904fa75.png",import.meta.url).href;export{a as default};
