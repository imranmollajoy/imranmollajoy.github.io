import{_ as r}from"./_page-dc5b7bcd.js";import{default as t}from"../components/pages/portfolios/_page.svelte-dc88f8e8.js";export{t as component,r as shared};
