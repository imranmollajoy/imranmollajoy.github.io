import{default as t}from"../components/pages/portfolios/watchnext/_page.svx-4916c5c4.js";export{t as component};
