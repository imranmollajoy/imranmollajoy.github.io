const t=""+new URL("../assets/thumb2-f1e57964.png",import.meta.url).href;export{t as default};
