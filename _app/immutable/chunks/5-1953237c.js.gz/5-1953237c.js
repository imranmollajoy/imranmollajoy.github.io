import{default as t}from"../components/pages/portfolios/bring-your-umbrella/_page.svx-abf5e7fc.js";export{t as component};
