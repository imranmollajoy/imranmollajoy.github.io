import{default as t}from"../components/error.svelte-cb99f465.js";export{t as component};
