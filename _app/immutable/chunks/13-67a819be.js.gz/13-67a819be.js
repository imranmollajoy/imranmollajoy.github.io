import{default as t}from"../components/pages/posts/why-i-chose-sveltekit-over-gatsby/_page.svx-2d37453c.js";export{t as component};
