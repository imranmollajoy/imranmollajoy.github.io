import{_ as r}from"./_page-a1b7d4c2.js";import{default as t}from"../components/pages/_page.svelte-8292c199.js";export{t as component,r as shared};
