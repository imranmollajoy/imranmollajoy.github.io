import{default as t}from"../components/pages/posts/differences-between-ssg-and-spa/_page.svx-037f11be.js";export{t as component};
