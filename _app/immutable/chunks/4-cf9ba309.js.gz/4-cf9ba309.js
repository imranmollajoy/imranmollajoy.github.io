import{default as t}from"../components/pages/portfolios/blog-with-svelte/_page.svx-31c2536d.js";export{t as component};
