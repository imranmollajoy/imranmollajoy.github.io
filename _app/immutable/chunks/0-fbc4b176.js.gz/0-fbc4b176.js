import{_ as r}from"./_layout-10dc9958.js";import{default as t}from"../components/pages/_layout.svelte-e1df3f76.js";export{t as component,r as shared};
