import{default as t}from"../components/pages/portfolios/watchnext/_page.svx-5fd1136d.js";export{t as component};
