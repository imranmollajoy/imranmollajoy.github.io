import{default as t}from"../components/pages/posts/why-i-chose-sveltekit-over-gatsby/_page.svx-732ad4b3.js";export{t as component};
