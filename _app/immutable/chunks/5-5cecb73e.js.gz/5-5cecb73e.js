import{default as t}from"../components/pages/portfolios/bring-your-umbrella/_page.svx-3ecae476.js";export{t as component};
