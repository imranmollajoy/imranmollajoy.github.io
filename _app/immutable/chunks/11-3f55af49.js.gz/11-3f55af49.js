import{default as t}from"../components/pages/posts/differences-between-ssg-and-spa/_page.svx-f674931b.js";export{t as component};
