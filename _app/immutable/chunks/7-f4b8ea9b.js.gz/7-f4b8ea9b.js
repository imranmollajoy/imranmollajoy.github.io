import{default as t}from"../components/pages/portfolios/take-note-app/_page.svx-f0698ce2.js";export{t as component};
