import{default as t}from"../components/pages/portfolios/dummy-text-generator/_page.svx-c05ac3e6.js";export{t as component};
