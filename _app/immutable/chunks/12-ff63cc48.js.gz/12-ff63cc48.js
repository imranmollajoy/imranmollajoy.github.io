import{default as t}from"../components/pages/posts/horizontal-scroll-section/_page.svx-1fd4bf6b.js";export{t as component};
