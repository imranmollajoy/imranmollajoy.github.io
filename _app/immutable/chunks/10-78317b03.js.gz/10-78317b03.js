import{default as t}from"../components/pages/posts/ad-free-alternatives-on-android-and-ios/_page.svx-68236c86.js";export{t as component};
