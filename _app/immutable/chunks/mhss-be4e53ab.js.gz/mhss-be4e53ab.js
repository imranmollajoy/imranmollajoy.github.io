const s=""+new URL("../assets/mhss-784515de.png",import.meta.url).href;export{s as default};
