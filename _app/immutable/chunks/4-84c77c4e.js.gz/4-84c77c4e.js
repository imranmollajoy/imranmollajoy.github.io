import{default as t}from"../components/pages/portfolios/blog-with-svelte/_page.svx-ec322617.js";export{t as component};
