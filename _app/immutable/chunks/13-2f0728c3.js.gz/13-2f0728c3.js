import{default as t}from"../components/pages/posts/why-i-chose-sveltekit-over-gatsby/_page.svx-4dfb042c.js";export{t as component};
