const t=""+new URL("../assets/thumb-c2bfef12.png",import.meta.url).href;export{t as default};
