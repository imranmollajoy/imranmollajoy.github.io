import{_ as r}from"./_layout-10dc9958.js";import{default as t}from"../components/pages/_layout.svelte-03600086.js";export{t as component,r as shared};
