import{default as t}from"../components/pages/posts/horizontal-scroll-section/_page.svx-5adcd639.js";export{t as component};
