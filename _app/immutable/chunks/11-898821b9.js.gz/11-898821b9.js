import{default as t}from"../components/pages/posts/differences-between-ssg-and-spa/_page.svx-974aa5ea.js";export{t as component};
