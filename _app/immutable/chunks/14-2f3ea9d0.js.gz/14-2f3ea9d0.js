import{_ as e}from"./_page-02a16c4f.js";export{e as shared};
