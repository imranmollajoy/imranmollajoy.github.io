import{default as t}from"../components/pages/posts/horizontal-scroll-section/_page.svx-6f74c000.js";export{t as component};
