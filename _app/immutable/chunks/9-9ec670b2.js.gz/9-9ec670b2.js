import{_ as r}from"./_page-bc9dc9fd.js";import{default as t}from"../components/pages/posts/_page.svelte-2090212c.js";export{t as component,r as shared};
