const t=""+new URL("../assets/first-1931ebb5.png",import.meta.url).href;export{t as default};
