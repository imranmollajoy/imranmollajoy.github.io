import{default as t}from"../components/error.svelte-e2a5d132.js";export{t as component};
