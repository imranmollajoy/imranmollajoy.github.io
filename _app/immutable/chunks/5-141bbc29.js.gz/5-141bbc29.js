import{default as t}from"../components/pages/portfolios/bring-your-umbrella/_page.svx-c609835d.js";export{t as component};
