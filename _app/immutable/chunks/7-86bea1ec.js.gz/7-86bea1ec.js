import{default as t}from"../components/pages/portfolios/take-note-app/_page.svx-328e107d.js";export{t as component};
