import{default as t}from"../components/pages/posts/ad-free-alternatives-on-android-and-ios/_page.svx-4b8fe643.js";export{t as component};
