import{default as t}from"../components/pages/portfolios/take-note-app/_page.svx-05018a91.js";export{t as component};
