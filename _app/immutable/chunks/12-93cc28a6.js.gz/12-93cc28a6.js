import{default as t}from"../components/pages/posts/horizontal-scroll-section/_page.svx-5e40f2f6.js";export{t as component};
