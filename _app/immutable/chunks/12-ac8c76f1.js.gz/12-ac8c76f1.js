import{default as t}from"../components/pages/posts/horizontal-scroll-section/_page.svx-eff20893.js";export{t as component};
