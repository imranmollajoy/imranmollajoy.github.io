import{l}from"../../../chunks/_page-bc9dc9fd.js";export{l as load};
